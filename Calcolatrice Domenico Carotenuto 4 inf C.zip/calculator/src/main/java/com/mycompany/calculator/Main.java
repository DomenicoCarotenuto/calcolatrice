
package com.mycompany.calculator;


public class Main {

    
    public static void main(String[] args) {
        calcolatrice c = new calcolatrice();
        c.setVisible(true);
    }
    
}
